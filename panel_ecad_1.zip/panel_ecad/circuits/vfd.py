"""
VFD Drive — Power Circuit + Control Circuit
"""
import ezdxf, sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from symbols.symbol_library import *


def vfd_power(msp, feeder, ox, oy):
    tag    = feeder["tag"]
    kw     = feeder.get("kw","15kW")
    mccb_r = feeder.get("mccb","40A")
    ics    = feeder.get("ics","25kA")
    cable  = feeder.get("cable","6mm²")
    vfd_tag= feeder.get("vfd_tag", f"VFD-{tag}")
    rpm    = feeder.get("rpm","variable")
    phases = [ox+10, ox+20, ox+30]

    for px in phases:
        draw_wire_v(msp, px, oy+185, oy+173, layer="POWER")
        add_text(msp, ["L1","L2","L3"][phases.index(px)],
                 px, oy+187, height=1.8, layer="TEXT")

    # MCCB
    draw_mccb(msp, ox+20, oy+150, tag=f"QM-{tag}", rating=mccb_r, ics=ics)
    for px in phases:
        draw_wire_v(msp, px, oy+173, oy+163, layer="POWER")

    # Line reactor (optional)
    if feeder.get("line_reactor", True):
        lr_y = oy+140
        for px in phases:
            draw_wire_v(msp, px, oy+150, lr_y+8, layer="POWER")
            for ay in [lr_y, lr_y+3, lr_y+6]:
                msp.add_arc((px, ay+1.5), 1.5, 0, 180,
                            dxfattribs={"layer":"POWER","color":4})
        add_text(msp, "LINE REACTOR", ox+35, lr_y+4,
                 height=1.8, layer="NOTES", halign="LEFT")
        y_vfd_in = lr_y
    else:
        for px in phases:
            draw_wire_v(msp, px, oy+150, oy+140, layer="POWER")
        y_vfd_in = oy+140

    # VFD block
    vfd_y = y_vfd_in - 30
    draw_vfd_block(msp, ox+20, vfd_y, tag=vfd_tag, kw=kw)
    for px in phases:
        draw_wire_v(msp, px, y_vfd_in, vfd_y+25, layer="POWER")

    # Output cable
    out_y = vfd_y - 8
    for px in phases:
        draw_wire_v(msp, px, vfd_y, out_y, layer="POWER")
    add_text(msp, f"SCREENED {cable}", ox+33, out_y+4,
             height=1.5, layer="TEXT", halign="LEFT")

    # Output isolation contactor
    iso_y = out_y - 15
    draw_contactor(msp, ox+20, iso_y, tag=f"KM-{tag}(ISO)")
    for px in phases:
        draw_wire_v(msp, px, out_y, iso_y+12, layer="POWER")

    # Motor
    mot_y = iso_y - 30
    draw_motor(msp, ox+20, mot_y, tag=tag, kw=kw, rpm=rpm)
    for px in phases:
        draw_wire_v(msp, px, iso_y, mot_y+12, layer="POWER")

    draw_earth(msp, ox+20, mot_y-7)

    add_text(msp, "⚡ USE SCREENED CABLE VFD→MOTOR  MAX 50m",
             ox+20, mot_y-18, height=2, layer="NOTES")
    add_text(msp, "DO NOT USE OVERLOAD RELAY ON VFD OUTPUT",
             ox+20, mot_y-23, height=1.8, layer="NOTES")
    add_text(msp, f"VFD POWER – {tag} ({kw})",
             ox+20, oy+192, height=2.5, layer="TEXT")


def vfd_control(msp, feeder, ox, oy):
    tag    = feeder["tag"]
    kw     = feeder.get("kw","15kW")
    vfd_tag= feeder.get("vfd_tag", f"VFD-{tag}")
    speed_src = feeder.get("speed_source","4-20mA from PLC")
    xL = ox+15
    xN = ox+120
    y  = oy+260

    draw_wire_v(msp, xL, y, oy+50, layer="CONTROL")
    draw_wire_v(msp, xN, y, oy+50, layer="CONTROL")
    add_text(msp, "L(24VDC/230VAC)", xL, y+5, height=2, layer="TEXT")
    add_text(msp, "N/0V",            xN, y+5, height=2, layer="TEXT")

    draw_mccb(msp, xL, y-15, tag="F1", rating="2A", ics="", layer="CONTROL")

    # VFD Terminal Block representation
    vx, vy = ox+35, oy+110
    msp.add_lwpolyline(
        [(vx-15,vy),(vx+65,vy),(vx+65,vy+80),(vx-15,vy+80),(vx-15,vy)],
        dxfattribs={"layer":"CONTROL","color":4}
    )
    add_text(msp, f"{vfd_tag} CONTROL TERMINALS",
             vx+25, vy+76, height=2.5, layer="TEXT")

    terminals = [
        ("DI1","RUN/STOP FWD",  vy+62),
        ("DI2","FWD/REV",       vy+52),
        ("DI3","FAULT RESET",   vy+42),
        ("DI4","SPEED PRESET",  vy+32),
        ("AI1","SPEED REF(4-20mA)", vy+20),
        ("DO1","RUN STATUS",    vy+10),
        ("DO2","FAULT OUTPUT",  vy+2),
    ]
    for term, desc, ty in terminals:
        add_text(msp, term, vx-13, ty, height=1.8, layer="TEXT", halign="LEFT")
        msp.add_line((vx-15,ty+1),(vx-22,ty+1), dxfattribs={"layer":"CONTROL"})
        add_text(msp, desc, vx+67, ty, height=1.8, layer="TEXT", halign="LEFT")

    # External wiring rungs
    # STOP→START to DI1
    y1 = y-35
    cx = xL+5
    draw_wire_h(msp, xL, cx, y1)
    draw_pb_nc(msp, cx, y1-5, tag="SB1\nSTOP")
    cx2 = cx+18
    draw_wire_h(msp, cx, cx2, y1)
    draw_wire_v(msp, cx, y1, y1-5); draw_wire_v(msp, cx, y1-15, y1-20)
    draw_pb_no(msp, cx2, y1-5, tag="SB2\nSTART")
    cx3 = cx2+18
    draw_wire_h(msp, cx2, cx3, y1)
    draw_wire_v(msp, cx2, y1, y1-5); draw_wire_v(msp, cx2, y1-15, y1-20)
    # Wire to DI1
    draw_wire_v(msp, cx3, y1, vy+63)
    draw_wire_h(msp, cx3, vx-22, vy+63)
    add_text(msp, "→DI1", vx-30, vy+63, height=1.8, layer="TEXT", halign="RIGHT")

    # Selector L-O-R to DI2
    draw_selector_sw(msp, cx3+5, y1-22, tag="SS1\nF/R", positions="F-O-R")
    draw_wire_v(msp, cx3+5, y1-22, vy+53)
    draw_wire_h(msp, cx3+5, vx-22, vy+53)
    add_text(msp, "→DI2", vx-30, vy+53, height=1.8, layer="TEXT", halign="RIGHT")

    # Speed ref AI1 note
    add_text(msp, f"AI1 ← {speed_src}",
             vx-15, vy-8, height=1.8, layer="NOTES", halign="LEFT")

    # DO1 → RUN lamp
    y_run = vy-25
    draw_wire_h(msp, vx-22, vx-22+20, y_run)
    draw_lamp(msp, vx-22+20, y_run-3, tag="HL1\nRUN", color_txt="GREEN")
    draw_wire_h(msp, vx-22+20, xN, y_run)
    draw_wire_v(msp, vx-22, vy+11, y_run)
    add_text(msp, "DO1→", vx-30, vy+11, height=1.8, layer="TEXT", halign="RIGHT")

    # DO2 → FAULT lamp
    y_flt = y_run-20
    draw_wire_h(msp, vx-22, vx-22+20, y_flt)
    draw_lamp(msp, vx-22+20, y_flt-3, tag="HL2\nFAULT", color_txt="RED")
    draw_wire_h(msp, vx-22+20, xN, y_flt)
    draw_wire_v(msp, vx-22, vy+3, y_flt)
    add_text(msp, "DO2→", vx-30, vy+3, height=1.8, layer="TEXT", halign="RIGHT")

    add_text(msp, f"VFD CONTROL – {tag} ({kw})",
             (xL+xN)//2, oy+265, height=2.5, layer="TEXT")
    add_text(msp, f"VFD: {vfd_tag}  |  SPEED REF: {speed_src}",
             (xL+xN)//2, oy+55, height=1.8, layer="NOTES")


def generate_vfd(feeder, power_path, control_path, panel_tag="MCC-1", drg_prefix="EL"):
    doc = ezdxf.new("R2010"); setup_layers(doc); msp = doc.modelspace()
    draw_title_block(msp, "VFD POWER CIRCUIT",
                     f"{feeder['tag']} – {feeder.get('kw','?')}",
                     f"{drg_prefix}-PWR-{feeder['tag']}", panel_tag=panel_tag)
    draw_busbar(msp, 10, 90, 300, label=f"415V BUS – {panel_tag}")
    vfd_power(msp, feeder, 10, 80)
    doc.saveas(power_path)
    print(f"    ✔ VFD Power: {power_path}")

    doc = ezdxf.new("R2010"); setup_layers(doc); msp = doc.modelspace()
    draw_title_block(msp, "VFD CONTROL CIRCUIT",
                     f"{feeder['tag']} – {feeder.get('kw','?')}",
                     f"{drg_prefix}-CTL-{feeder['tag']}", panel_tag=panel_tag)
    vfd_control(msp, feeder, 5, 0)
    doc.saveas(control_path)
    print(f"    ✔ VFD Control: {control_path}")
