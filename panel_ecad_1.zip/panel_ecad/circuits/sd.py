"""
Star-Delta Starter — Power Circuit + Control Circuit
"""
import ezdxf, sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from symbols.symbol_library import *


def sd_power(msp, feeder, ox, oy):
    tag    = feeder["tag"]
    kw     = feeder.get("kw","22kW")
    mccb_r = feeder.get("mccb","63A")
    ics    = feeder.get("ics","25kA")
    olr_s  = feeder.get("olr","30-40A")
    cable  = feeder.get("cable","10mm²")
    rpm    = feeder.get("rpm","1450")
    phases = [ox+10, ox+20, ox+30]

    for px in phases:
        draw_wire_v(msp, px, oy+170, oy+158, layer="POWER")
        add_text(msp, ["L1","L2","L3"][phases.index(px)],
                 px, oy+172, height=1.8, layer="TEXT")

    # MCCB
    draw_mccb(msp, ox+20, oy+135, tag=f"QM-{tag}", rating=mccb_r, ics=ics)
    for px in phases:
        draw_wire_v(msp, px, oy+158, oy+148, layer="POWER")

    # Main contactor KM1
    draw_contactor(msp, ox+20, oy+115, tag=f"KM1-{tag}")
    for px in phases:
        draw_wire_v(msp, px, oy+135, oy+127, layer="POWER")

    # OLR
    draw_olr(msp, ox+20, oy+97, tag=f"KH-{tag}", setting=olr_s)
    for px in phases:
        draw_wire_v(msp, px, oy+115, oy+104, layer="POWER")

    # Cable to motor
    for px in phases:
        draw_wire_v(msp, px, oy+97, oy+80, layer="POWER")
    add_text(msp, cable, ox+33, oy+88, height=1.5, layer="TEXT", halign="LEFT")

    # Motor (6 terminals U1V1W1 / U2V2W2)
    draw_motor(msp, ox+20, oy+58, tag=tag, kw=kw, rpm=rpm)
    for px in phases:
        draw_wire_v(msp, px, oy+80, oy+65, layer="POWER")

    # STAR contactor KM3 (U2V2W2 shorting)
    star_x = ox-25
    draw_contactor(msp, star_x, oy+30, tag=f"KM3(STAR)")
    for i, px in enumerate([star_x-3, star_x, star_x+3]):
        msp.add_line((px, oy+58-7),(px, oy+42),
                     dxfattribs={"layer":"POWER"})
    draw_wire_h(msp, star_x-3, star_x+3, oy+28, layer="POWER")
    add_text(msp, "U2V2W2", star_x, oy+26, height=1.8, layer="TEXT")

    # DELTA contactor KM2 (U1-W2, V1-U2, W1-V2)
    delta_x = ox+50
    draw_contactor(msp, delta_x, oy+97, tag=f"KM2(DELTA)")
    for i, px in enumerate([delta_x-3, delta_x, delta_x+3]):
        msp.add_line((px, oy+115),(px, oy+109), dxfattribs={"layer":"POWER"})
        msp.add_line((px, oy+97), (px, oy+88),  dxfattribs={"layer":"POWER"})

    # Interlock note
    add_text(msp, "⚡ KM2 & KM3 MECHANICALLY INTERLOCKED",
             ox+20, oy+22, height=2, layer="NOTES")
    draw_earth(msp, ox+20, oy+51)
    add_text(msp, f"STAR-DELTA POWER – {tag} ({kw})",
             ox+20, oy+178, height=2.5, layer="TEXT")


def sd_control(msp, feeder, ox, oy):
    tag    = feeder["tag"]
    kw     = feeder.get("kw","22kW")
    delay  = feeder.get("timer","10s")
    remote = feeder.get("remote", False)
    xL = ox+15
    xN = ox+110
    y  = oy+255

    draw_wire_v(msp, xL, y, oy+50, layer="CONTROL")
    draw_wire_v(msp, xN, y, oy+50, layer="CONTROL")
    add_text(msp, "L(230V)", xL, y+5, height=2, layer="TEXT")
    add_text(msp, "N",       xN, y+5, height=2, layer="TEXT")

    draw_mccb(msp, xL, y-15, tag="F1", rating="2A", ics="", layer="CONTROL")

    cx = xL+5
    # ── Rung 1: STOP→START→OLR NC→KM1 coil ──
    y1 = y-35
    draw_wire_h(msp, xL, cx, y1)
    draw_pb_nc(msp, cx, y1-5, tag="SB1\nSTOP")
    cx2 = cx+18
    draw_wire_h(msp, cx, cx2, y1)
    draw_wire_v(msp, cx, y1, y1-5); draw_wire_v(msp, cx, y1-15, y1-20)
    draw_pb_no(msp, cx2, y1-5, tag="SB2\nSTART")
    cx3 = cx2+18
    draw_wire_h(msp, cx2, cx3, y1)
    draw_wire_v(msp, cx2, y1, y1-5); draw_wire_v(msp, cx2, y1-15, y1-20)
    draw_olr_nc(msp, cx3, y1-4, tag=f"KH-{tag}")
    cx4 = cx3+16
    draw_wire_h(msp, cx3, cx4, y1)
    draw_wire_v(msp, cx3, y1, y1-4); draw_wire_v(msp, cx3, y1-12, y1-20)
    draw_nc_contact(msp, cx4, y1-4, tag=f"KM2\nNC")   # KM2 interlock
    cx5 = cx4+15
    draw_wire_h(msp, cx4, cx5, y1)
    draw_wire_v(msp, cx4, y1, y1-4); draw_wire_v(msp, cx4, y1-12, y1-20)
    draw_coil(msp, cx5, y1-3, tag=f"KM1-{tag}")
    draw_wire_h(msp, cx5, xN, y1)
    draw_wire_v(msp, cx5, y1, y1-3); draw_wire_v(msp, cx5, y1-9, y1-20)

    # ── Rung 2: KM1 Seal-in ──
    y2 = y1-28
    draw_wire_h(msp, xL, cx2, y2)
    draw_no_contact(msp, cx2, y2-4, tag=f"KM1\n13-14")
    draw_wire_h(msp, cx2, cx5, y2)
    draw_wire_v(msp, cx2, y2, y2-4); draw_wire_v(msp, cx2, y2-12, y2-20)
    draw_wire_h(msp, cx5, xN, y2)

    # ── Rung 3: KM1 NO → Timer KT1 coil ──
    y3 = y2-28
    draw_wire_h(msp, xL, cx3, y3)
    draw_no_contact(msp, cx3, y3-4, tag=f"KM1\nNO")
    draw_wire_h(msp, cx3, cx5, y3)
    draw_wire_v(msp, cx3, y3, y3-4); draw_wire_v(msp, cx3, y3-12, y3-20)
    draw_timer_coil(msp, cx5, y3-3, tag=f"KT1-{tag}", delay=delay)
    draw_wire_h(msp, cx5, xN, y3)
    draw_wire_v(msp, cx5, y3, y3-3); draw_wire_v(msp, cx5, y3-9, y3-20)

    # ── Rung 4: STAR contactor KM3 (KM1 NO + KM2 NC + KT1 NC) ──
    y4 = y3-28
    draw_wire_h(msp, xL, cx2, y4)
    draw_no_contact(msp, cx2, y4-4, tag=f"KM1\nNO")
    draw_wire_h(msp, cx2, cx3, y4)
    draw_wire_v(msp, cx2, y4, y4-4); draw_wire_v(msp, cx2, y4-12, y4-20)
    draw_nc_contact(msp, cx3, y4-4, tag=f"KM2\nNC")   # Interlock
    draw_wire_h(msp, cx3, cx4, y4)
    draw_wire_v(msp, cx3, y4, y4-4); draw_wire_v(msp, cx3, y4-12, y4-20)
    draw_nc_contact(msp, cx4, y4-4, tag=f"KT1\nNC(TON)")
    draw_wire_h(msp, cx4, cx5, y4)
    draw_wire_v(msp, cx4, y4, y4-4); draw_wire_v(msp, cx4, y4-12, y4-20)
    draw_coil(msp, cx5, y4-3, tag=f"KM3\n(STAR)")
    draw_wire_h(msp, cx5, xN, y4)
    draw_wire_v(msp, cx5, y4, y4-3); draw_wire_v(msp, cx5, y4-9, y4-20)

    # ── Rung 5: DELTA KM2 (KT1 NO + KM3 NC) ──
    y5 = y4-28
    draw_wire_h(msp, xL, cx3, y5)
    draw_no_contact(msp, cx3, y5-4, tag=f"KT1\nNO(TON)")
    draw_wire_h(msp, cx3, cx4, y5)
    draw_wire_v(msp, cx3, y5, y5-4); draw_wire_v(msp, cx3, y5-12, y5-20)
    draw_nc_contact(msp, cx4, y5-4, tag=f"KM3\nNC")   # Interlock
    draw_wire_h(msp, cx4, cx5, y5)
    draw_wire_v(msp, cx4, y5, y5-4); draw_wire_v(msp, cx4, y5-12, y5-20)
    draw_coil(msp, cx5, y5-3, tag=f"KM2\n(DELTA)")
    draw_wire_h(msp, cx5, xN, y5)
    draw_wire_v(msp, cx5, y5, y5-3); draw_wire_v(msp, cx5, y5-9, y5-20)

    # ── RUN lamp ──
    y6 = y5-25
    draw_wire_h(msp, xL, cx4, y6)
    draw_no_contact(msp, cx4, y6-4, tag=f"KM2\nNO")
    draw_wire_h(msp, cx4, cx5, y6)
    draw_wire_v(msp, cx4, y6, y6-4); draw_wire_v(msp, cx4, y6-12, y6-20)
    draw_lamp(msp, cx5, y6-3, tag="HL1\nRUN", color_txt="GREEN")
    draw_wire_h(msp, cx5, xN, y6)
    draw_wire_v(msp, cx5, y6, y6-3); draw_wire_v(msp, cx5, y6-9, y6-20)

    # ── FAULT lamp ──
    y7 = y6-25
    draw_wire_h(msp, xL, cx4, y7)
    draw_nc_contact(msp, cx4, y7-4, tag=f"KH-{tag}\nNC")
    cx7 = cx4+15
    draw_wire_h(msp, cx4, cx7, y7)
    draw_wire_v(msp, cx4, y7, y7-4); draw_wire_v(msp, cx4, y7-12, y7-20)
    draw_lamp(msp, cx7, y7-3, tag="HL2\nFAULT", color_txt="RED")
    draw_wire_h(msp, cx7, xN, y7)
    draw_wire_v(msp, cx7, y7, y7-3); draw_wire_v(msp, cx7, y7-9, y7-20)

    add_text(msp, f"TIMER: {delay} (STAR→DELTA)",
             (xL+xN)//2, y7-15, height=2, layer="NOTES")
    add_text(msp, f"SD CONTROL – {tag} ({kw})",
             (xL+xN)//2, oy+260, height=2.5, layer="TEXT")


def generate_sd(feeder, power_path, control_path, panel_tag="MCC-1", drg_prefix="EL"):
    doc = ezdxf.new("R2010"); setup_layers(doc); msp = doc.modelspace()
    draw_title_block(msp, "STAR-DELTA POWER CIRCUIT",
                     f"{feeder['tag']} – {feeder.get('kw','?')}",
                     f"{drg_prefix}-PWR-{feeder['tag']}", panel_tag=panel_tag)
    draw_busbar(msp, 10, 90, 285, label=f"415V BUS – {panel_tag}")
    sd_power(msp, feeder, 10, 80)
    doc.saveas(power_path)
    print(f"    ✔ SD Power: {power_path}")

    doc = ezdxf.new("R2010"); setup_layers(doc); msp = doc.modelspace()
    draw_title_block(msp, "STAR-DELTA CONTROL CIRCUIT",
                     f"{feeder['tag']} – {feeder.get('kw','?')}",
                     f"{drg_prefix}-CTL-{feeder['tag']}", panel_tag=panel_tag)
    sd_control(msp, feeder, 5, 0)
    doc.saveas(control_path)
    print(f"    ✔ SD Control: {control_path}")
