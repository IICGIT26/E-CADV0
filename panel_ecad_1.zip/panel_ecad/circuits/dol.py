"""
DOL Starter — Power Circuit + Control Circuit
"""
import ezdxf, sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from symbols.symbol_library import *


def dol_power(msp, feeder, ox, oy):
    """Draw DOL power circuit at offset (ox, oy)"""
    tag    = feeder["tag"]
    kw     = feeder.get("kw","7.5kW")
    mccb_r = feeder.get("mccb","25A")
    ics    = feeder.get("ics","25kA")
    cont_r = feeder.get("contactor","18A")
    olr_s  = feeder.get("olr","13-18A")
    cable  = feeder.get("cable","4mm²")
    rpm    = feeder.get("rpm","1450")
    phases = [ox+10, ox+20, ox+30]

    # Busbar connections
    for px in phases:
        draw_wire_v(msp, px, oy+160, oy+148, layer="POWER")

    # MCCB
    draw_mccb(msp, ox+20, oy+125, tag=f"QM-{tag}", rating=mccb_r, ics=ics)
    for px in phases:
        draw_wire_v(msp, px, oy+148, oy+138, layer="POWER")

    # CT (if ammeter specified)
    if feeder.get("ammeter", False):
        draw_ct(msp, ox+20, oy+118, ratio=feeder.get("ct_ratio","100/5A"))
        for px in phases:
            draw_wire_v(msp, px, oy+125, oy+118, layer="POWER")
        y_cont_top = oy+118
    else:
        y_cont_top = oy+125

    # Contactor
    draw_contactor(msp, ox+20, oy+100, tag=f"KM-{tag}")
    for px in phases:
        draw_wire_v(msp, px, y_cont_top, oy+112, layer="POWER")

    # OLR
    draw_olr(msp, ox+20, oy+82, tag=f"KH-{tag}", setting=olr_s)
    for px in phases:
        draw_wire_v(msp, px, oy+100, oy+89, layer="POWER")

    # Cable to motor
    for px in phases:
        draw_wire_v(msp, px, oy+82, oy+65, layer="POWER")
    add_text(msp, cable, ox+33, oy+73, height=1.5, layer="TEXT", halign="LEFT")

    # Motor
    draw_motor(msp, ox+20, oy+45, tag=tag, kw=kw, rpm=rpm)
    for px in phases:
        draw_wire_v(msp, px, oy+65, oy+52, layer="POWER")

    # Earth
    draw_earth(msp, ox+20, oy+38)

    # Phase labels
    for px, lbl in zip(phases, ["L1","L2","L3"]):
        add_text(msp, lbl, px, oy+162, height=1.8, layer="TEXT")


def dol_control(msp, feeder, ox, oy):
    """Draw DOL control circuit ladder at offset (ox, oy)"""
    tag    = feeder["tag"]
    kw     = feeder.get("kw","7.5kW")
    remote = feeder.get("remote", False)
    xL = ox+15   # Phase rail
    xN = ox+95   # Neutral rail
    y  = oy+245

    # Rails
    draw_wire_v(msp, xL, y, oy+50, layer="CONTROL")
    draw_wire_v(msp, xN, y, oy+50, layer="CONTROL")
    add_text(msp, "L(230V)", xL,  y+5, height=2, layer="TEXT")
    add_text(msp, "N",       xN,  y+5, height=2, layer="TEXT")

    # Control MCB
    draw_mccb(msp, xL, y-15, tag="F1", rating="2A", ics="", layer="CONTROL")

    # ── Rung 1: STOP(NC)→START(NO)→KM seal-in→OLR NC→KM Coil ──
    y1 = y - 35
    cx = xL+5
    draw_wire_h(msp, xL, cx, y1)

    # STOP NC
    draw_pb_nc(msp, cx, y1-5, tag="SB1\nSTOP")
    cx2 = cx+18
    draw_wire_h(msp, cx, cx2, y1)
    draw_wire_v(msp, cx, y1, y1-5)
    draw_wire_v(msp, cx, y1-15, y1-20)

    # START NO
    draw_pb_no(msp, cx2, y1-5, tag="SB2\nSTART")
    cx3 = cx2+18
    draw_wire_h(msp, cx2, cx3, y1)
    draw_wire_v(msp, cx2, y1, y1-5)
    draw_wire_v(msp, cx2, y1-15, y1-20)

    # OLR NC
    draw_olr_nc(msp, cx3, y1-4, tag=f"KH-{tag}")
    cx4 = cx3+15
    draw_wire_h(msp, cx3, cx4, y1)
    draw_wire_v(msp, cx3, y1, y1-4)
    draw_wire_v(msp, cx3, y1-12, y1-20)

    # KM Coil
    draw_coil(msp, cx4, y1-3, tag=f"KM-{tag}")
    draw_wire_h(msp, cx4, xN, y1)
    draw_wire_v(msp, cx4, y1, y1-3)
    draw_wire_v(msp, cx4, y1-9, y1-20)

    # ── Rung 2: KM Seal-in NO ──
    y2 = y1-28
    draw_wire_h(msp, xL, cx2, y2)
    draw_no_contact(msp, cx2, y2-4, tag=f"KM-{tag}\n13-14")
    draw_wire_h(msp, cx2, cx3, y2)
    draw_wire_v(msp, cx2, y2, y2-4)
    draw_wire_v(msp, cx2, y2-12, y2-20)
    draw_wire_h(msp, cx3, cx4, y2)
    draw_wire_h(msp, cx4, xN, y2)

    # ── Rung 3: Remote START (optional) ──
    if remote:
        y3 = y2-25
        draw_wire_h(msp, xL, cx2, y3)
        draw_no_contact(msp, cx2, y3-4, tag="REMOTE\nSTART")
        draw_wire_h(msp, cx2, cx4, y3)
        draw_wire_v(msp, cx2, y3, y3-4)
        draw_wire_v(msp, cx2, y3-12, y3-20)
        draw_wire_h(msp, cx4, xN, y3)
        y_base = y3
    else:
        y_base = y2

    # ── Rung: RUN lamp (GREEN) ──
    y4 = y_base-28
    draw_wire_h(msp, xL, cx3, y4)
    draw_no_contact(msp, cx3, y4-4, tag=f"KM-{tag}\nNO")
    cx5 = cx3+15
    draw_wire_h(msp, cx3, cx5, y4)
    draw_wire_v(msp, cx3, y4, y4-4)
    draw_wire_v(msp, cx3, y4-12, y4-20)
    draw_lamp(msp, cx5, y4-3, tag="HL1\nRUN", color_txt="GREEN")
    draw_wire_h(msp, cx5, xN, y4)
    draw_wire_v(msp, cx5, y4, y4-3)
    draw_wire_v(msp, cx5, y4-9, y4-20)

    # ── Rung: TRIP/FAULT lamp (RED) ──
    y5 = y4-28
    draw_wire_h(msp, xL, cx4, y5)
    draw_nc_contact(msp, cx4, y5-4, tag=f"KH-{tag}\nNC")
    cx6 = cx4+15
    draw_wire_h(msp, cx4, cx6, y5)
    draw_wire_v(msp, cx4, y5, y5-4)
    draw_wire_v(msp, cx4, y5-12, y5-20)
    draw_lamp(msp, cx6, y5-3, tag="HL2\nFAULT", color_txt="RED")
    draw_wire_h(msp, cx6, xN, y5)
    draw_wire_v(msp, cx6, y5, y5-3)
    draw_wire_v(msp, cx6, y5-9, y5-20)

    # ── Selector switch (L-O-R if specified) ──
    if feeder.get("selector_sw", True):
        draw_selector_sw(msp, xL+5, y-22, tag="SS1", positions="L-O-R")

    add_text(msp, f"DOL CONTROL – {tag} ({kw})",
             (xL+xN)/2, oy+250, height=2.5, layer="TEXT")


def generate_dol(feeder, power_path, control_path, panel_tag="MCC-1", drg_prefix="EL"):
    # Power
    doc = ezdxf.new("R2010"); setup_layers(doc); msp = doc.modelspace()
    draw_title_block(msp, "DOL POWER CIRCUIT",
                     f"{feeder['tag']} – {feeder.get('kw','?')}",
                     f"{drg_prefix}-PWR-{feeder['tag']}", panel_tag=panel_tag)
    draw_busbar(msp, 20, 60, 275, label=f"415V BUS – {panel_tag}")
    dol_power(msp, feeder, 0, 80)
    doc.saveas(power_path)
    print(f"    ✔ DOL Power: {power_path}")

    # Control
    doc = ezdxf.new("R2010"); setup_layers(doc); msp = doc.modelspace()
    draw_title_block(msp, "DOL CONTROL CIRCUIT",
                     f"{feeder['tag']} – {feeder.get('kw','?')}",
                     f"{drg_prefix}-CTL-{feeder['tag']}", panel_tag=panel_tag)
    dol_control(msp, feeder, 10, 0)
    doc.saveas(control_path)
    print(f"    ✔ DOL Control: {control_path}")
