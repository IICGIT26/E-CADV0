"""
Panel E-CAD — PCC / PMCC / MCC Circuit & MTO Generator
Run: streamlit run app.py
"""
import streamlit as st
import os, sys, io, zipfile, tempfile, copy

sys.path.insert(0, os.path.dirname(__file__))
from circuits.dol import generate_dol
from circuits.sd  import generate_sd
from circuits.vfd import generate_vfd
from circuits.mto import generate_mto

st.set_page_config(page_title="Panel E-CAD", page_icon="⚡", layout="wide")

st.markdown("""
<style>
.title{font-size:2.2rem;font-weight:900;color:#1F4E79}
.sub  {font-size:1rem;color:#666;margin-bottom:1.5rem}
.stButton>button{background:#1F4E79;color:white;border-radius:6px;
                  font-weight:700;padding:.5rem 1.2rem}
.badge{display:inline-block;padding:2px 10px;border-radius:10px;
       font-weight:700;font-size:.8rem;margin:2px}
.dol{background:#E9F7EF;color:#1E8449}
.sd {background:#EBF5FB;color:#1A5276}
.vfd{background:#F5EEF8;color:#6C3483}
</style>
""", unsafe_allow_html=True)

st.markdown('<div class="title">⚡ Panel E-CAD Generator</div>', unsafe_allow_html=True)
st.markdown('<div class="sub">PCC · PMCC · MCC — Power Circuit + Control Circuit + MTO  |  No plant config needed</div>',
            unsafe_allow_html=True)

# ── Default feeder template ───────────────────────────────────
DEFAULT_FEEDER = {
    "tag":"M-101","type":"DOL","kw":"7.5kW","mccb":"25A","ics":"25kA",
    "contactor":"18A","olr":"13-18A","cable":"4c×4mm²","cable_len":25,
    "rpm":"1450","timer":"10s","vfd_tag":"","speed_source":"4-20mA from PLC",
    "ammeter":False,"line_reactor":True,"remote":False,"selector_sw":True
}

# ── Session state ─────────────────────────────────────────────
if "feeders" not in st.session_state:
    st.session_state.feeders = [copy.deepcopy(DEFAULT_FEEDER)]
if "panel" not in st.session_state:
    st.session_state.panel = {
        "panel_tag":"MCC-1","panel_type":"MCC","bus_voltage":"415V",
        "bus_rating":"800A","incomer":"ACB 800A","incomer_cable":"70mm²",
        "cable_len":50,"project":"MY PROJECT","drg_no":"EL-MTO-001"
    }

panel = st.session_state.panel

# ════════════════════════════════════════════
# PANEL HEADER
# ════════════════════════════════════════════
with st.expander("📦 Panel Details", expanded=True):
    c1,c2,c3,c4 = st.columns(4)
    panel["panel_tag"]   = c1.text_input("Panel Tag",   panel["panel_tag"])
    panel["panel_type"]  = c2.selectbox("Panel Type",   ["MCC","PMCC","PCC","DB","SMDB"],
                            index=["MCC","PMCC","PCC","DB","SMDB"].index(panel["panel_type"]))
    panel["bus_voltage"] = c3.selectbox("Bus Voltage",  ["415V","440V","380V","690V"])
    panel["bus_rating"]  = c4.text_input("Bus Rating",  panel["bus_rating"])

    c5,c6,c7,c8 = st.columns(4)
    panel["incomer"]         = c5.text_input("Incomer Type",     panel["incomer"])
    panel["incomer_cable"]   = c6.text_input("Incomer Cable",    panel["incomer_cable"])
    panel["cable_len"]       = c7.number_input("Incomer Cable Len (m)", value=panel["cable_len"], step=5)
    panel["project"]         = c8.text_input("Project Name",     panel["project"])
    panel["drg_no"]          = c1.text_input("DRG / MTO Ref",    panel["drg_no"])

st.markdown("---")

# ════════════════════════════════════════════
# FEEDER TABLE
# ════════════════════════════════════════════
st.subheader("⚡ Feeder / Motor Schedule")

col_cfg = {
    "tag":         st.column_config.TextColumn("Tag",          width="small"),
    "type":        st.column_config.SelectboxColumn("Starter", width="small",
                       options=["DOL","SD","VFD"]),
    "kw":          st.column_config.TextColumn("Motor kW",     width="small"),
    "mccb":        st.column_config.TextColumn("MCCB",         width="small"),
    "ics":         st.column_config.TextColumn("Ics (kA)",     width="small"),
    "contactor":   st.column_config.TextColumn("Contactor",    width="small"),
    "olr":         st.column_config.TextColumn("OLR Setting",  width="small"),
    "cable":       st.column_config.TextColumn("Cable Size",   width="small"),
    "cable_len":   st.column_config.NumberColumn("Cable Len(m)",width="small"),
    "rpm":         st.column_config.TextColumn("RPM",          width="small"),
    "timer":       st.column_config.TextColumn("Timer (SD)",   width="small"),
    "vfd_tag":     st.column_config.TextColumn("VFD Tag",      width="small"),
    "speed_source":st.column_config.TextColumn("Speed Ref",    width="medium"),
    "ammeter":     st.column_config.CheckboxColumn("Ammeter",  width="small"),
    "remote":      st.column_config.CheckboxColumn("Remote Ctrl",width="small"),
    "selector_sw": st.column_config.CheckboxColumn("Sel.SW",   width="small"),
}

edited = st.data_editor(
    st.session_state.feeders,
    num_rows="dynamic",
    use_container_width=True,
    column_config=col_cfg,
    key="feeder_table"
)
st.session_state.feeders = edited

# Stats bar
if edited:
    dol_n = sum(1 for f in edited if f.get("type","DOL").upper()=="DOL")
    sd_n  = sum(1 for f in edited if f.get("type","DOL").upper()=="SD")
    vfd_n = sum(1 for f in edited if f.get("type","DOL").upper()=="VFD")
    st.markdown(
        f'<span class="badge dol">DOL × {dol_n}</span>'
        f'<span class="badge sd">Star-Delta × {sd_n}</span>'
        f'<span class="badge vfd">VFD × {vfd_n}</span>'
        f'&nbsp;&nbsp;Total feeders: **{len(edited)}** &nbsp;|&nbsp;'
        f'Drawings: **{len(edited)*2}** DXF + **1** MTO Excel',
        unsafe_allow_html=True
    )

st.markdown("---")

# ════════════════════════════════════════════
# GENERATE BUTTON
# ════════════════════════════════════════════
st.subheader("🚀 Generate Documents")

gcol1, gcol2, gcol3 = st.columns(3)
gen_power   = gcol1.checkbox("⚡ Power Circuits",   value=True)
gen_control = gcol2.checkbox("🔧 Control Circuits", value=True)
gen_mto     = gcol3.checkbox("📊 MTO (Excel)",      value=True)

if st.button("⚡ GENERATE NOW", use_container_width=True):
    feeders = st.session_state.feeders
    if not feeders:
        st.warning("Please add at least one feeder.")
        st.stop()

    panel_cfg = {**panel, "feeders": feeders}
    drg_prefix = panel["drg_no"].split("-")[0] if "-" in panel["drg_no"] else "EL"
    ptag = panel["panel_tag"]

    with st.spinner("Generating circuits..."):
        zip_buf = io.BytesIO()
        file_count = 0

        with tempfile.TemporaryDirectory() as tmpdir:
            dxf_dir   = os.path.join(tmpdir, "DXF_Circuits")
            excel_dir = os.path.join(tmpdir, "Excel_MTO")
            os.makedirs(dxf_dir,   exist_ok=True)
            os.makedirs(excel_dir, exist_ok=True)

            errors = []
            log    = []

            for feeder in feeders:
                if not feeder.get("tag"): continue
                ftag  = feeder["tag"]
                ftype = feeder.get("type","DOL").upper()

                try:
                    pwr = os.path.join(dxf_dir, f"{ftag}_{ftype}_POWER.dxf")
                    ctl = os.path.join(dxf_dir, f"{ftag}_{ftype}_CONTROL.dxf")

                    if ftype == "DOL":
                        if gen_power:   generate_dol(feeder, pwr, ctl, ptag, drg_prefix)
                        elif gen_control: generate_dol(feeder, pwr, ctl, ptag, drg_prefix)
                        else:             generate_dol(feeder, pwr, ctl, ptag, drg_prefix)
                    elif ftype == "SD":
                        generate_sd(feeder, pwr, ctl, ptag, drg_prefix)
                    elif ftype == "VFD":
                        generate_vfd(feeder, pwr, ctl, ptag, drg_prefix)

                    if gen_power and os.path.exists(pwr):
                        log.append(f"✔ {os.path.basename(pwr)}")
                        file_count += 1
                    if gen_control and os.path.exists(ctl):
                        log.append(f"✔ {os.path.basename(ctl)}")
                        file_count += 1

                except Exception as e:
                    errors.append(f"❌ {ftag}: {e}")

            # MTO
            if gen_mto:
                try:
                    mto_path = os.path.join(excel_dir,
                                            f"{ptag}_MTO.xlsx")
                    generate_mto(panel_cfg, mto_path)
                    log.append(f"✔ {os.path.basename(mto_path)}")
                    file_count += 1
                except Exception as e:
                    errors.append(f"❌ MTO: {e}")

            # Build ZIP
            with zipfile.ZipFile(zip_buf,"w",zipfile.ZIP_DEFLATED) as zf:
                for folder, subf, files in os.walk(tmpdir):
                    for fname in files:
                        fpath = os.path.join(folder, fname)
                        arcname = os.path.relpath(fpath, tmpdir)
                        if (gen_power   and "_POWER.dxf"   in fname) or \
                           (gen_control and "_CONTROL.dxf" in fname) or \
                           (gen_mto     and fname.endswith(".xlsx")):
                            zf.write(fpath, arcname)
            zip_buf.seek(0)

        if errors:
            for e in errors:
                st.error(e)

        if file_count > 0:
            st.success(f"✅ {file_count} files generated!")
            zname = f"{ptag}_{panel['panel_type']}_Circuits_MTO.zip"
            st.download_button(
                f"📥 Download {file_count} Files (ZIP)",
                zip_buf, zname, "application/zip",
                use_container_width=True
            )
            with st.expander("📋 Generated Files"):
                for l in log:
                    st.markdown(f"`{l}`")

# ════════════════════════════════════════════
# QUICK REFERENCE
# ════════════════════════════════════════════
with st.expander("📖 Quick Reference — What Gets Generated"):
    st.markdown("""
| Starter | Power Circuit DXF | Control Circuit DXF | MTO Excel |
|---|---|---|---|
| **DOL** | MCCB→Contactor→OLR→Motor | STOP/START/Seal-in/OLR-NC/Coil/Lamps | ✅ |
| **Star-Delta** | MCCB→KM1/KM2/KM3→OLR→Motor | STOP/START/KM1/Timer/KM3(STAR)/KM2(DELTA) | ✅ |
| **VFD** | MCCB→Line Reactor→VFD→Iso Contactor→Motor | DI1-4/AI1/DO1-2 terminal wiring | ✅ |

**MTO Includes:**
- Panel incomer (ACB/MCCB), busbar, PT, voltmeter
- All MCCBs, contactors, OLRs, timers, VFDs
- Push buttons, selector switches, pilot lamps, control MCBs
- Terminal blocks, DIN rails, wire ducts, ferrules
- Power cables, control cables, cable glands
- Panel enclosure, accessories, earthing

**Open DXF files with:**  DraftSight (free) · LibreCAD (free) · QCAD (free) · AutoCAD
""")
