"""
IEC Electrical Symbol Library for Panel Circuits
"""
import ezdxf
from ezdxf.enums import TextEntityAlignment


def setup_layers(doc):
    layers = {
        "POWER":   (1, 35), "CONTROL": (5, 18),
        "BUSBAR":  (1, 50), "TEXT":    (7, 13),
        "BORDER":  (7, 50), "TITLE":   (7, 35),
        "NOTES":   (8, 13), "SYMBOL":  (2, 18),
        "CABLE":   (3, 18), "DIM":     (8, 13),
    }
    for name, (color, lw) in layers.items():
        try:
            doc.layers.add(name, color=color, lineweight=lw)
        except Exception:
            pass


def add_text(msp, text, x, y, height=1.8, layer="TEXT", halign="CENTER"):
    attribs = {"layer": layer, "height": height, "color": 7}
    t = msp.add_text(text, dxfattribs=attribs)
    align_map = {
        "CENTER": TextEntityAlignment.CENTER,
        "LEFT":   TextEntityAlignment.LEFT,
        "RIGHT":  TextEntityAlignment.RIGHT,
    }
    t.set_placement((x, y), align=align_map.get(halign, TextEntityAlignment.CENTER))


def draw_title_block(msp, title, sub, drg_no, rev="A", panel_tag="", W=420, H=297):
    """A3 Landscape title block"""
    msp.add_lwpolyline(
        [(10,10),(W-10,10),(W-10,H-10),(10,H-10),(10,10)],
        dxfattribs={"layer":"BORDER","lineweight":50}
    )
    msp.add_lwpolyline(
        [(10,10),(W-10,10),(W-10,42),(10,42),(10,10)],
        dxfattribs={"layer":"BORDER"}
    )
    for d in [150, 250, 320, 370]:
        msp.add_line((d,10),(d,42), dxfattribs={"layer":"BORDER"})
    msp.add_line((10,26),(W-10,26), dxfattribs={"layer":"BORDER"})

    add_text(msp, title,           80,  35, height=4.5, layer="TITLE")
    add_text(msp, sub,             80,  17, height=3,   layer="TITLE")
    add_text(msp, f"PANEL: {panel_tag}", 200, 35, height=2.5, layer="TITLE")
    add_text(msp, f"DRG: {drg_no}",     200, 17, height=2.2, layer="TITLE")
    add_text(msp, f"REV: {rev}",        285, 35, height=2.5, layer="TITLE")
    add_text(msp, "APPROVED: ___",      285, 17, height=2,   layer="TITLE")
    add_text(msp, "DATE: ___",          345, 35, height=2.2, layer="TITLE")
    add_text(msp, "ELEC CAD AUTO",      395, 35, height=1.8, layer="TITLE")
    add_text(msp, "SCALE: NTS",         395, 17, height=1.8, layer="TITLE")


# ══════════════════════════════════════════════
# POWER CIRCUIT SYMBOLS
# ══════════════════════════════════════════════

def draw_mccb(msp, x, y, tag="MCCB", rating="100A", ics="25kA", layer="POWER"):
    msp.add_lwpolyline(
        [(x-3,y),(x+3,y),(x+3,y+9),(x-3,y+9),(x-3,y)],
        dxfattribs={"layer":layer,"color":1}
    )
    for px in [x-2, x, x+2]:
        msp.add_line((px,y+9),(px,y+13),  dxfattribs={"layer":layer})
        msp.add_line((px,y),  (px,y-4),   dxfattribs={"layer":layer})
        msp.add_line((px-1,y+2),(px+1,y+7),dxfattribs={"layer":layer,"color":1})
    add_text(msp, tag,    x+5,  y+9,  height=1.8, layer="TEXT", halign="LEFT")
    add_text(msp, rating, x+5,  y+6,  height=1.5, layer="TEXT", halign="LEFT")
    add_text(msp, ics,    x+5,  y+3,  height=1.3, layer="TEXT", halign="LEFT")


def draw_acb(msp, x, y, tag="ACB", rating="1600A", layer="POWER"):
    msp.add_lwpolyline(
        [(x-5,y),(x+5,y),(x+5,y+13),(x-5,y+13),(x-5,y)],
        dxfattribs={"layer":layer,"color":1,"lineweight":35}
    )
    for px in [x-3, x, x+3]:
        msp.add_line((px,y+13),(px,y+17), dxfattribs={"layer":layer})
        msp.add_line((px,y),   (px,y-5),  dxfattribs={"layer":layer})
    add_text(msp, "ACB",  x,   y+6,  height=3,   layer="TEXT")
    add_text(msp, tag,    x+7, y+11, height=2,   layer="TEXT", halign="LEFT")
    add_text(msp, rating, x+7, y+7,  height=1.8, layer="TEXT", halign="LEFT")


def draw_contactor(msp, x, y, tag="KM1", layer="POWER"):
    msp.add_lwpolyline(
        [(x-4,y),(x+4,y),(x+4,y+8),(x-4,y+8),(x-4,y)],
        dxfattribs={"layer":layer,"color":3}
    )
    for px in [x-3, x, x+3]:
        msp.add_line((px,y+8), (px,y+12), dxfattribs={"layer":layer})
        msp.add_line((px,y),   (px,y-4),  dxfattribs={"layer":layer})
        msp.add_line((px-1,y+2),(px+1,y+6),dxfattribs={"layer":layer,"color":3})
    add_text(msp, tag, x+6, y+6, height=1.8, layer="TEXT", halign="LEFT")


def draw_olr(msp, x, y, tag="OLR", setting="", layer="POWER"):
    msp.add_lwpolyline(
        [(x-3,y),(x+3,y),(x+3,y+7),(x-3,y+7),(x-3,y)],
        dxfattribs={"layer":layer,"color":2}
    )
    for px in [x-2, x, x+2]:
        msp.add_line((px,y+7),(px,y+11),  dxfattribs={"layer":layer})
        msp.add_line((px,y),  (px,y-4),   dxfattribs={"layer":layer})
        msp.add_arc( (px,y+3.5), 1.2, 0, 180, dxfattribs={"layer":layer,"color":2})
    add_text(msp, tag,     x+5, y+6,  height=1.8, layer="TEXT", halign="LEFT")
    add_text(msp, setting, x+5, y+3,  height=1.3, layer="TEXT", halign="LEFT")


def draw_motor(msp, x, y, tag="M1", kw="7.5kW", rpm="1450", layer="POWER"):
    r = 7
    msp.add_circle((x,y), r, dxfattribs={"layer":layer,"color":5})
    add_text(msp, "M",   x, y+1.5, height=4,   layer="TEXT")
    add_text(msp, "3~",  x, y-2.5, height=2,   layer="TEXT")
    for px in [x-4, x, x+4]:
        msp.add_line((px,y+r),(px,y+r+5), dxfattribs={"layer":layer})
    add_text(msp, tag, x+10, y+4,  height=2.2, layer="TEXT", halign="LEFT")
    add_text(msp, kw,  x+10, y+1,  height=1.8, layer="TEXT", halign="LEFT")
    add_text(msp, f"{rpm}rpm", x+10, y-2, height=1.5, layer="TEXT", halign="LEFT")


def draw_vfd_block(msp, x, y, tag="VFD1", kw="15kW", layer="SYMBOL"):
    msp.add_lwpolyline(
        [(x-7,y),(x+7,y),(x+7,y+20),(x-7,y+20),(x-7,y)],
        dxfattribs={"layer":layer,"color":4}
    )
    add_text(msp, "VFD",  x, y+14, height=3.5, layer="TEXT")
    add_text(msp, tag,    x, y+10, height=2.0, layer="TEXT")
    add_text(msp, kw,     x, y+6,  height=1.8, layer="TEXT")
    add_text(msp, "INPUT",  x, y+21, height=1.5, layer="TEXT")
    add_text(msp, "OUTPUT", x, y-2,  height=1.5, layer="TEXT")
    for px in [x-4, x, x+4]:
        msp.add_line((px,y+20),(px,y+25), dxfattribs={"layer":layer})
        msp.add_line((px,y),   (px,y-5),  dxfattribs={"layer":layer})


def draw_busbar(msp, x1, x2, y, label="", layer="BUSBAR"):
    msp.add_line((x1,y),(x2,y),
                 dxfattribs={"layer":layer,"color":1,"lineweight":50})
    if label:
        add_text(msp, label, x1-3, y+1, height=2, layer="TEXT", halign="RIGHT")


def draw_earth(msp, x, y, layer="POWER"):
    msp.add_line((x,y),(x,y-5), dxfattribs={"layer":layer,"color":3})
    for i, w in enumerate([5,3.5,2]):
        msp.add_line((x-w,y-5-i*2),(x+w,y-5-i*2),
                     dxfattribs={"layer":layer,"color":3})


def draw_ct(msp, x, y, ratio="100/5A", layer="SYMBOL"):
    msp.add_circle((x,y+3), 2.5, dxfattribs={"layer":layer,"color":6})
    msp.add_line((x,y+7),(x,y+5.5), dxfattribs={"layer":layer})
    msp.add_line((x,y+0.5),(x,y),   dxfattribs={"layer":layer})
    add_text(msp, "CT",   x+3.5, y+4, height=1.5, layer="TEXT", halign="LEFT")
    add_text(msp, ratio,  x+3.5, y+1, height=1.3, layer="TEXT", halign="LEFT")


# ══════════════════════════════════════════════
# CONTROL CIRCUIT SYMBOLS
# ══════════════════════════════════════════════

def draw_no_contact(msp, x, y, tag="", layer="CONTROL"):
    msp.add_line((x,y+8),(x,y+5),   dxfattribs={"layer":layer})
    msp.add_line((x,y+3),(x,y),     dxfattribs={"layer":layer})
    msp.add_line((x-2,y+5),(x+2,y+5),dxfattribs={"layer":layer})
    msp.add_line((x-2,y+3),(x+2,y+3),dxfattribs={"layer":layer})
    if tag:
        add_text(msp, tag, x+3, y+4, height=1.5, layer="TEXT", halign="LEFT")


def draw_nc_contact(msp, x, y, tag="", layer="CONTROL"):
    msp.add_line((x,y+8),(x,y+5),    dxfattribs={"layer":layer})
    msp.add_line((x,y+3),(x,y),      dxfattribs={"layer":layer})
    msp.add_line((x-2,y+5),(x+2,y+5),dxfattribs={"layer":layer})
    msp.add_line((x-2,y+3),(x+2,y+3),dxfattribs={"layer":layer})
    msp.add_line((x-2,y+5),(x+2,y+3),dxfattribs={"layer":layer,"color":1})
    if tag:
        add_text(msp, tag, x+3, y+4, height=1.5, layer="TEXT", halign="LEFT")


def draw_pb_no(msp, x, y, tag="PB", color_txt="GREEN", layer="CONTROL"):
    msp.add_line((x,y+10),(x,y+6),   dxfattribs={"layer":layer})
    msp.add_line((x,y+4), (x,y),     dxfattribs={"layer":layer})
    msp.add_line((x-2,y+6),(x+2,y+6),dxfattribs={"layer":layer,"color":3})
    msp.add_line((x-2,y+4),(x+2,y+4),dxfattribs={"layer":layer})
    msp.add_circle((x,y+7.5), 1.2,   dxfattribs={"layer":layer,"color":3})
    add_text(msp, tag,       x+3, y+7, height=1.5, layer="TEXT", halign="LEFT")
    add_text(msp, color_txt, x+3, y+5, height=1.3, layer="TEXT", halign="LEFT")


def draw_pb_nc(msp, x, y, tag="PB", color_txt="RED", layer="CONTROL"):
    msp.add_line((x,y+10),(x,y+6),   dxfattribs={"layer":layer})
    msp.add_line((x,y+4), (x,y),     dxfattribs={"layer":layer})
    msp.add_line((x-2,y+6),(x+2,y+6),dxfattribs={"layer":layer,"color":1})
    msp.add_line((x-2,y+4),(x+2,y+4),dxfattribs={"layer":layer})
    msp.add_line((x-2,y+6),(x+2,y+4),dxfattribs={"layer":layer,"color":1})
    msp.add_circle((x,y+7.5), 1.2,   dxfattribs={"layer":layer,"color":1})
    add_text(msp, tag,       x+3, y+7, height=1.5, layer="TEXT", halign="LEFT")
    add_text(msp, color_txt, x+3, y+5, height=1.3, layer="TEXT", halign="LEFT")


def draw_selector_sw(msp, x, y, tag="SS", positions="L-O-R", layer="CONTROL"):
    msp.add_circle((x,y+4), 2.5, dxfattribs={"layer":layer,"color":4})
    msp.add_line((x,y+4),(x+2.5,y+4), dxfattribs={"layer":layer,"color":4})
    msp.add_line((x,y+8),(x,y+6.5),   dxfattribs={"layer":layer})
    msp.add_line((x,y+1.5),(x,y),     dxfattribs={"layer":layer})
    add_text(msp, tag,       x+4, y+5, height=1.5, layer="TEXT", halign="LEFT")
    add_text(msp, positions, x+4, y+3, height=1.3, layer="TEXT", halign="LEFT")


def draw_coil(msp, x, y, tag="KM1", layer="CONTROL"):
    msp.add_line((x,y+6),(x,y+4),   dxfattribs={"layer":layer})
    msp.add_line((x,y+2),(x,y),     dxfattribs={"layer":layer})
    msp.add_lwpolyline(
        [(x-2,y+2),(x+2,y+2),(x+2,y+4),(x-2,y+4),(x-2,y+2)],
        dxfattribs={"layer":layer,"color":3}
    )
    add_text(msp, tag, x+3, y+3, height=1.8, layer="TEXT", halign="LEFT")


def draw_timer_coil(msp, x, y, tag="KT1", delay="5s", layer="CONTROL"):
    msp.add_line((x,y+6),(x,y+4),   dxfattribs={"layer":layer})
    msp.add_line((x,y+2),(x,y),     dxfattribs={"layer":layer})
    msp.add_lwpolyline(
        [(x-2,y+2),(x+2,y+2),(x+2,y+4),(x-2,y+4),(x-2,y+2)],
        dxfattribs={"layer":layer,"color":4}
    )
    msp.add_circle((x,y+3), 0.8, dxfattribs={"layer":layer,"color":4})
    add_text(msp, tag,   x+3, y+4, height=1.8, layer="TEXT", halign="LEFT")
    add_text(msp, delay, x+3, y+2, height=1.5, layer="TEXT", halign="LEFT")


def draw_olr_nc(msp, x, y, tag="OLR", layer="CONTROL"):
    draw_nc_contact(msp, x, y, tag=tag, layer=layer)
    msp.add_circle((x,y+4), 0.7, dxfattribs={"layer":layer,"color":2})


def draw_lamp(msp, x, y, tag="HL", color_txt="RED", layer="CONTROL"):
    msp.add_line((x,y+6),(x,y+4),  dxfattribs={"layer":layer})
    msp.add_line((x,y+2),(x,y),    dxfattribs={"layer":layer})
    msp.add_circle((x,y+3), 2,     dxfattribs={"layer":layer,"color":1})
    msp.add_line((x-1.4,y+1.6),(x+1.4,y+4.4),dxfattribs={"layer":layer})
    msp.add_line((x+1.4,y+1.6),(x-1.4,y+4.4),dxfattribs={"layer":layer})
    add_text(msp, tag,       x+3, y+4, height=1.5, layer="TEXT", halign="LEFT")
    add_text(msp, color_txt, x+3, y+2, height=1.3, layer="TEXT", halign="LEFT")


def draw_ammeter(msp, x, y, tag="A", layer="CONTROL"):
    msp.add_circle((x,y+3), 2.5, dxfattribs={"layer":layer,"color":6})
    add_text(msp, "A",  x, y+3, height=2.5, layer="TEXT")
    msp.add_line((x,y+6),(x,y+5.5), dxfattribs={"layer":layer})
    msp.add_line((x,y+0.5),(x,y),   dxfattribs={"layer":layer})
    add_text(msp, tag, x+3.5, y+3, height=1.5, layer="TEXT", halign="LEFT")


def draw_voltmeter(msp, x, y, tag="V", layer="CONTROL"):
    msp.add_circle((x,y+3), 2.5, dxfattribs={"layer":layer,"color":6})
    add_text(msp, "V",  x, y+3, height=2.5, layer="TEXT")
    msp.add_line((x,y+6),(x,y+5.5), dxfattribs={"layer":layer})
    msp.add_line((x,y+0.5),(x,y),   dxfattribs={"layer":layer})
    add_text(msp, tag, x+3.5, y+3, height=1.5, layer="TEXT", halign="LEFT")


def draw_wire_h(msp, x1, x2, y, layer="CONTROL"):
    msp.add_line((x1,y),(x2,y), dxfattribs={"layer":layer})


def draw_wire_v(msp, x, y1, y2, layer="CONTROL"):
    msp.add_line((x,y1),(x,y2), dxfattribs={"layer":layer})


def draw_junction(msp, x, y, layer="CONTROL"):
    msp.add_circle((x,y), 0.7, dxfattribs={"layer":layer,"color":7})
